#include<iostream>
#include<string>
#include<random>
#include<fstream>
#include<sstream>

static const int RAGE_ATK = 5;
static const int SP_ATK = 7;

std::random_device dev;
std::mt19937 rng(dev());
std::uniform_int_distribution<std::mt19937::result_type> dist2(1,2);
std::uniform_int_distribution<std::mt19937::result_type> dist3(1,3);

class Creature;

enum class ActionType {
    SimpleAttack = 0,
    PaladinAttack = 1,
    DruidAttack = 2,
    RogueAttack = 3,
    ArcherAttack = 4,
    HobgoblinAttack = 5,
    ShieldDefence = 6,
    DodgeDefence = 7,
    PaladinDefence = 8,
    DruidDefence = 9,
    RogueDefence = 10
};


class Action {
  public:
    ActionType type;
    Action(ActionType type) : type(type) {}
    virtual void perform(Creature* performer, Creature* victim = nullptr) = 0;

    virtual ~Action() {}
};

class Creature {
  public:  
    const std::string klass;
    int hp;
    int sp;
    const int maxhp;
    const int def;
    const int atk;
    const int maxsp;
    const std::string name;
    Creature* enemy = nullptr;
    std::vector<Action*> skills;
    int shielded = 0;
    int dodging = 0;
    int rage = 0;
    bool charge = false;

    Creature(int php, int psp, int patk, int pdef, std::string pname, std::string pclass)
        : hp(php), sp(psp), maxhp(php), def(pdef), maxsp(psp), name(pname), atk(patk), klass(pclass) {}

    virtual ~Creature() {
        for(Action* act : skills)
        {
            delete act;
        }
    }
};

class Attack : public Action {
  public:
    Attack(ActionType ptype) : Action(ptype) {}

    void perform(Creature* performer, Creature* target) override {
        if(performer->dodging && dist2(rng) == 2) {
            std::cout << target->name << " dodges " << performer->name << "'s attack!\n";
        }
        else {
            int real_atk = performer->atk;
            if(performer->rage) {
                real_atk += RAGE_ATK;
            }
            if(target->shielded) {
                real_atk = real_atk / 2;
            }
            real_atk = std::max(real_atk - target->def, 1);

            target->sp -= SP_ATK;
            target->hp -= real_atk;
            if (type == ActionType::SimpleAttack) {
                std::cout << performer->name << " hits " << target->name << " for " << real_atk << "HP!\n";
            }
            else if (type == ActionType::PaladinAttack) {
                performer->rage = 4;
                real_atk = std::max(real_atk / 2, 1);
                std::cout << performer->name << " sends a holy smite upon " << target->name << " for " << real_atk << "HP!\n" << performer->name << " gets a blessing for 3 turns!\n";
            }
            else if (type == ActionType::DruidAttack) {
                std::cout << performer->name << " tries to use a special attack and ";
                if (dist2(rng) == 2) {
                    real_atk *= 2;
                    std::cout << "succeeds!\n" << performer->name << " tears " << target->name << " 's life for " << real_atk << "HP!\n";
                } else {
                    real_atk = std::max(real_atk / 2, 1);
                    std::cout << "fails!\n" << performer->name << " hits " << target->name << " for " << real_atk << "HP!\n";
                }
            } else if (type == ActionType::RogueAttack) {
                if(target->hp / target->maxhp < 0.2) {
                    target->hp = 0;
                    std::cout << performer->name << " sees " << target->name << " 's weakness and finishes them!\n";
                }
                else {
                    real_atk = std::max(real_atk / 2, 1);
                    target->hp -= real_atk;
                    std::cout << performer->name << "'s attempt to kill is blocked!\n" << performer->name << " hits " << target->name << " for " << real_atk << "HP!\n";
                }
            }
            else if (type == ActionType::ArcherAttack) {
                if(performer->charge) {
                    performer->charge = false;
                    real_atk = real_atk * 3;
                    std::cout << performer->name << " shoots a dark arrow at " << target->name << " for " << real_atk << "HP!\n";
                }
                else {
                    performer->charge = true;
                    target->sp += SP_ATK;
                    std::cout << performer->name << " is charging a dark arrow...\n";
                }
            }
            else if (type == ActionType::HobgoblinAttack) {
                if(performer->charge) {
                    performer->charge = false;
                    real_atk = real_atk * 2;
                    std::cout << performer->name << " hits " << target->name << " with a combo for " << real_atk << "HP!\n";
                }
                else {
                    performer->charge = true;
                    target->sp -= SP_ATK;
                    std::cout << performer->name << "'s roar strikes fear in " << target->name << "'s heart!\n" << performer->name << " is prepairing a combo...\n";
                }
            }
        }
    }

    virtual ~Attack() {}
};

std::vector<std::string> descriptions{
    "Simple attack",
    "Holy smite that grants temporary power boost",
    "Powerful attack with a chance to fail",
    "Attack that finishes enemies with low health",
    "Powerful attack that charges for 1 turn",
    "Very powerful attack that charges for 1 turn",
    "Decreases half of the damage taken this turn",
    "Gives chance to dodge attack this turn",
    "Recovers some SP",
    "Recovers some HP",
    "Gives damage boost for 3 turns"
};

class Defence : public Action {
public:
    Defence(ActionType type) : Action(type) {}

    void perform(Creature* performer, Creature* target) override {
        if (type == ActionType::ShieldDefence) {
            performer->shielded = 1;
            std::cout << performer->name << " takes a defensive stance with the shield. Damage reduced for 1 turn!\n";
        }
        else if (type == ActionType::DodgeDefence) {
            performer->dodging = 1;
            std::cout << performer->name << " takes a defensive stance to dodge next attack. 50'%' chance to avoid next attack!\n";
        }
        else if (type == ActionType::PaladinDefence) {
            performer->sp = std::min(performer->maxsp, performer->sp + 20);
            std::cout << performer->name << " prays for salvation and feels the presence of divine powers. 20 SP recovered!\n";
        }
        else if (type == ActionType::DruidDefence) {
            performer->hp = std::min(performer->maxhp, performer->hp + 20);
            std::cout << performer->name << " calls for mother nature's help and finds life force lying within. 20 HP recovered!\n";
        }
        else if (type == ActionType::RogueDefence) {
            performer->rage = 4;
            std::cout << performer->name << " concentrates on the enemy and inspects their weak spots. Damage increased for 3 turns!\n";
        }
    }

    virtual ~Defence() {}
};

class Human;

class Monster : public Creature {
  public:
    Human* curr_enemy = nullptr;

    Monster(int php, int patk, int pdef, std::string pname, std::string pklass) :
        Creature(php, 0, patk, pdef, pname, pklass) {}
};

class Human : public Creature {
  public:
    Monster* curr_enemy = nullptr;

    Human(int php, int psp, int patk, int pdef, std::string pname, std::string pklass) :
        Creature(php, psp, patk, pdef, pname, pklass) {}

    virtual void attack(Monster* mon) {}

    virtual void defend() {}

    virtual void special_attack(Monster* mon) {}

    virtual void special_skill() {}

    void check() {
        if(curr_enemy != nullptr) {
            std::cout << curr_enemy->name << "(" << curr_enemy->hp << "/" << curr_enemy->maxhp << " HP)\n";
        }
        //TODODODODODODODODO
    }

    void status() {
        std::cout << name << "(" << hp << "/" << maxhp << " HP) (" << sp << "/" << maxsp << "SP)\n";
    }

    virtual ~Human() {}
};

class Paladin : public Human {
  public:
    Paladin(int php, int psp, int patk, int pdef, std::string pname) : Human(php, psp, patk, pdef, pname, "Paladin") {}

    void attack(Monster* mon) override {
        skills[0]->perform(this, mon);
    }

    void defend() override {
        skills[2]->perform(this, nullptr);
    }

    void special_attack(Monster* mon)
    {
        skills[1]->perform(this, mon);
    }

    void special_skill() override {
        skills[3]->perform(this, nullptr);
    }
};

class Worg : public Monster {
  public:
    Worg(int php, int patk, int pdef, std::string pname) : Monster(php, patk, pdef, pname, "Worg") {}
};

class GodOfWar {
  public:
    std::vector<Creature*> sons;

    template<typename T>
    T* createHuman(int hp, int sp, int atk, int def, std::string name) {
        T* human_ptr = new T(hp, sp, atk, def, name);
        sons.push_back(human_ptr);
        Paladin* paladin_ptr = dynamic_cast<Paladin*>(human_ptr);
        if (paladin_ptr != nullptr) {
            Attack* attack_simple = new Attack(ActionType::SimpleAttack);
            Attack* attack_paladin = new Attack(ActionType::PaladinAttack);
            human_ptr->skills.push_back(attack_simple);
            human_ptr->skills.push_back(attack_paladin);
            Defence* defence_shield = new Defence(ActionType::ShieldDefence);
            Defence* defence_paladin = new Defence(ActionType::PaladinDefence);
            human_ptr->skills.push_back(defence_shield);
            human_ptr->skills.push_back(defence_paladin);
            return human_ptr;
        }
        //check for every other human
    }

    template<typename T>
    T* createMonster(int hp, int atk, int def, std::string name) {
        T* monster_ptr = new T(hp, atk, def, name);
        sons.push_back(monster_ptr);
        Worg* worg_ptr = dynamic_cast<Worg*>(monster_ptr);
        if (worg_ptr != nullptr) {
            Attack* attack_simple = new Attack(ActionType::SimpleAttack);
            monster_ptr->skills.push_back(attack_simple);
            return monster_ptr;
        }
    }


    ~GodOfWar() {
        for (Creature* creature : sons){
            delete creature;
        }
        std::cout << "hehehaha, that was fun\n";
    }
};

std::vector<Human*> humans;
std::vector<Monster*> monsters;

void duel(Human* hum, Monster* mon) {
    hum->curr_enemy = mon;
    mon->curr_enemy = hum;
    bool your_turn = true;
    int type;
    while (mon->hp > 0 && hum->hp > 0 && hum->sp > 0) {
        if(your_turn) {
            std::cout << hum->name << "'s turn!\nChoose your next action:\n";
            for(int i = 0; i < 4; i++) {
                std::cout << i + 1 << ": " << descriptions[int(((hum->skills)[i])->type)] << "\n";
            }
            std::cout << "5: Check your status\n6: Check your enemy's status\n(Input the number)\n";
            std::cin >> type;
            if(type > 6 || type < 1) {
                std::cout << "Invalid number! Try again.\n";
                continue;
            } else if (type < 5) {
                hum->skills[type - 1]->perform(hum, mon);
            } else if (type == 5) {
                hum->status();
            } else {
                hum->check();
            }
            your_turn = !your_turn;
            continue;
        }
        // monster utrn
        std::cout << "MONSTER TURN\n";
        your_turn = !your_turn;
    }
}

void battle() {
    std::cout << "Are you ready to begin, mortal? (y/n)\n";
    std::string ans;
    std::cin >> ans;
    Human* you = nullptr;
    int curr_hero;
    Monster* enemy;
    int alive_humans = humans.size();
    int alive_monsters = monsters.size();
    if(ans == "y" || ans == "Y") {
        std::cout << "Very well, let us begin!\n";
        while(alive_humans > 0 && alive_monsters > 0) {
            if(you == nullptr) {
                std::cout << "Choose your character:\n";
                for(Human* ptr : humans) {
                    if (ptr != nullptr) {
                        std::cout << ptr->name << " the " << ptr->klass << "\n";
                    }
                }
                std::cout << "Which will you choose? (input the name)\n";
                std::cin >> ans;
                you = nullptr;
                for(int i = 0; i < humans.size(); i++) {
                    if(humans[i] != nullptr && humans[i]->name == ans) {
                        you = humans[i];
                        curr_hero = i;
                        break;
                    }
                }
                if (you == nullptr) {
                    std::cout << "Invalid input! Try again.\n";
                    continue;
                }
            }
            enemy = monsters[monsters.size() - alive_monsters];
            duel(you, enemy);
            if(enemy->hp <= 0) {
                std::cout << enemy->name << " has been defeated!\n";
                alive_monsters--;
                if(alive_monsters > 0) {
                    std::cout << "Next enemy appears!\n";
                }
            } else {
                alive_humans--;
                if(you->hp <= 0) {
                    std::cout << you->name << " has been unalived!\n";
                } else {
                    std::cout << you->name << " fleed in fear!\n";
                }
                you = nullptr;
                humans[curr_hero] = nullptr;
            }
        }
        if(alive_humans == 0) {
            std::cout << "The humans were defeated! " << monsters.size() << "monsters remained.\n Better luck next time!\n";
        } else{
            std::cout << "The monters were defeated! " << humans.size() << "humans remained.\n Congratulations!\n";
        }
    } else if(ans == "n" || ans == "N") {
        std::cout << "Pfft, what a party pooper...\n";
    }
}

int main() {
    GodOfWar Ares;
    std::ifstream fin("humans.txt");
    std::string line;
    std::string cr_name;
    char type;
    int cr_hp;
    int cr_sp;
    int cr_atk;
    int cr_def;

    while (getline(fin, line)) {
        std::istringstream sin(line);
        sin >> type >> cr_name >> cr_hp >> cr_sp >> cr_atk >> cr_def;
        switch(type) {
            case 'P': {
                humans.push_back(Ares.createHuman<Paladin>(cr_hp, cr_sp, cr_atk, cr_def, cr_name));
                break;
            }
        }
        std::cout << line << std::endl;
    }
    fin.close();

    std::ifstream fin1("monsters.txt");
    while (getline(fin1, line)) {
        std::istringstream sin(line);
        sin >> type >> cr_name >> cr_hp >> cr_atk >> cr_def;
        switch(type) {
            case 'W': {
                monsters.push_back(Ares.createMonster<Worg>(cr_hp, cr_atk, cr_def, cr_name));
                break;
            }
        }
        std::cout << line << std::endl;
    }
    fin1.close();

    
    // TOTO: create vseh,

    battle();
    return 0; 
}